//Daboto, made by davidlao. Development started the 8th of January, 2021.
//Server-expansion began the 5th of March, 2021
//Development resumed July 22nd 2021

//As of Daboto 11 logging is also stored to a text file real-time.

//Necessary stuff
const Discord = require('discord.js');
const client = new Discord.Client();
const ms = require('ms');
const gifs = require('gifs-pro');
var badwordsArray = require('badwords/array'); //swear filter
var Trello = require("trello");
var trello = new Trello("88db755e573a53ddc3bb89b37c909ac3", "c168ef9db4987f402100d6aafb7ec94abe83c1a32e28048fa183fbd6a77cc0ab");
var SuggestionsListId = "604e5c84aae29e3cbccade68";
var VerificationListId = "604e5c917626540528024d42";

//Daboto 11 Remote DiscordCon
const { exec } = require("child_process");

var spawn = require('child_process').spawn;
function shspawn(command) {
   spawn('sh', ['-c', command], { stdio: 'inherit' });
} 

//Set the prefix.
const prefix = '>';

//Turn it online and log when ready
client.once('ready', () => {
console.log("[BASH] Making new log at 'latestlog.txt'...");
shspawn("touch latestlog.txt");
console.log("[BASH] OK. Daboto starting now.");
shspawn("echo '\n\nStarting Daboto...' >> latestlog.txt");
console.log('[INFO]: Daboto is now online')
console.log(`[BOT] Logged in as ${client.user.tag}!`);
console.log('[BOT] Console logging has begun.\n');
client.user.setActivity('you to >help', { type: 'WATCHING' })
shspawn("echo 'Set status!\n\nMessage log:' >> latestlog.txt");
console.log('[BOT] Bot status was set.\n');
});

//Commands and pre-command setup
client.on('message', async message =>{
   if(message.guild === null){
      console.log('User ' + message.author.tag + ' on DMs ' + '] said:\n"' + message.content + '"\n[Sent ' + message.createdAt + ']\n');
      shspawn("echo 'User " + message.author.tag + " on DMs " + " said:\n" + message.content + "\n[Sent " + message.createdAt + "]\n' >> latestlog.txt");
   }else{
      console.log('User ' + message.author.tag + ' at server ' + message.guild.name + '] said:\n"' + message.content + '"\n[Sent ' + message.createdAt + ']\n');
      shspawn("echo 'User " + message.author.tag + " at server " + message.guild.name + " said:\n" + message.content + "\n[Sent " + message.createdAt + "]\n' >> latestlog.txt");
   }
if(!message.content.startsWith(prefix) || message.author.bot) return;

var args = message.content.substring(prefix.length).split(" ");
var argsFix = message.content.split("");
const command = args.shift().toLowerCase();

//Echoify
if(command === 'say'){
message.delete()
message.channel.send(argsFix.splice(5,256).join("").replace('\n','\n'))
message.channel.send("Sent by: <@" + message.author.id + ">");
}

//GetPFP
if(command === 'pfp'){
   if(message.author.id == '403249595787902997'){
      message.author.send(message.mentions.users.first().displayAvatarURL());
      message.author.send('User: <@' + message.mentions.users.first().id + '>');
      message.channel.send('Sent right into your DMs! :D')
   }else{
      message.channel.send('Hey, <@' + message.author.id + '>, you cannot run that command. Your mod-level must be: **bot owner**');
   }
}

//Suggest
if(command === 'suggest'){
   if(message.guild === null){
      trello.addCard('Suggestion by ' + message.author.tag, argsFix.splice(8,512).join("").replace('\n','\n'), SuggestionsListId,
      function (error, trelloCard) {
          if (error) {
              console.log('Could not add card:', error);
          }
          else {
              console.log('Added card:', trelloCard);
          }
      });
message.channel.send("Thanks! Your suggestion was added, <@" + message.author.id + ">. Remember that suggestions have a 512 character limit!");
   }else{
      message.channel.send(":x: Sorry, as of Daboto 10b, this message is DM-only.");
   }
}

//Encrypt
if(command === 'encrypt/wth'){
message.delete()
message.channel.send(argsFix.splice(13,256).join("").replace(/void/g,'fV').replace(/and/g,'fuA').replace(/if/g,'aI').replace(/or/g,'fuO').replace(/\(/g,'oP').replace(/\)/g,'cP').replace(/\{/g,'oV').replace(/\}/g,'cV').replace(/print/g,'fuP'))
message.channel.send("Encrypted by: <@" + message.author.id + "> with davidlao's whattheheckryptioner");
}
   
//Unencrypt
if(command === 'unencrypt/wth'){
message.delete()
message.channel.send(argsFix.splice(15,256).join("").replace(/fV/g,'void').replace(/fuA/g,'and').replace(/aI/g,'if').replace(/fuO/g,'or').replace(/oP/g,'(').replace(/cP/g,')').replace(/oV/g,'{').replace(/cV/g,'}').replace(/fuP/g,'print'))
message.channel.send("Unencrypted by: <@" + message.author.id + "> with davidlao's un-whattheheckryptioner");
}

if(command === 'members'){
//.filter(member => !member.user.bot)
message.channel.send('This server has ' + client.guilds.cache.get(message.guild.id).memberCount + ' members!')
}

//General help embed
if(command === 'help'){
const generalHelpEmbed = new Discord.MessageEmbed()
.setColor('#FF0000')
.setTitle('Daboto Help')
.setDescription('Help section:')
.setImage('https://i.imgur.com/y1XR4jq.png')
.addFields(
{name: '>version', value: 'Gives current Daboto version information.'},
{name: '>members', value: 'Returns the member count of this server!'},
{name: '>mail (first mention) (message)', value: 'Mails the specified user!'},
{name: '>help/polls', value: 'Show help embed about polls commands.'},
{name: '>help/fun', value: 'Show help embed about fun commands.'},
{name: '>help/rate', value: 'Show help embed about rating poll commands.'},
{name: '>help/mod', value: 'Show help embed about moderation commands.'},
{name: '>help/gif', value: 'Show help embed about random gifs.'},
{name: '>help/pronouns', value: 'Show help embed about pronouns.'},
{name: '>help/encrypt', value: 'Shows an embed about encryption commands.'}
)
.setFooter('bot made by davidlao#3872')

message.channel.send(generalHelpEmbed);
}else

//Encryption help embed
if(command === 'help/encrypt'){
const generalHelpEmbed = new Discord.MessageEmbed()
.setColor('#FFFFFF')
.setTitle('Encryption:')
.setDescription('David, the bot developer likes encryption, so he made "encryption" commands:')
.setFooter('bot made by davidlao#3872')
.addFields(
{name: '>encrypt/wth -code-', value: 'Encrypts -code- via the davidlao whattheheckryptor'},
{name: '>unencrypt/wth -code-', value: 'Unencrypts -code- ENCRYPTED VIA the davidlao un-whattheheckryptor'},
)
message.channel.send(generalHelpEmbed);
} 
   
//Verify command
if(command === 'verify'){
  if (message.guild.roles.cache.find(role => role.name === 'Verified')){
      if(message.member.roles.cache.find(r => r.name === "Verified")) {
         message.channel.send('You are already verified! >:O');
      }else{
         let verifyRole = message.guild.roles.cache.find(role => role.name === 'Verified');
         message.member.roles.add(verifyRole);
         message.channel.send('You should/will be verified briefly! Welcome, <@' + message.author.id + '>')
        
         trello.addCard(message.member.user.tag + '\n[' + message.guild.name + ']', argsFix.splice(8,512).join(""), VerificationListId,
      function (error, trelloCard) {
          if (error) {
              console.log('Could not add card:', error);
          }
          else {
              console.log('Added card:', trelloCard);
          }
      });

            }
         
      }else{
         message.channel.send('The **Verified** role wasn\'t setup.');
      }
}

//Get version command
if(command === 'version'){
message.channel.send("Your server is currently using Daboto 11 [23rd of July 2021 LTS]. Made by davidlao#3872. You can invite the bot as of Daboto 8 with this link: <https://discord.com/oauth2/authorize?client_id=797159542692773940&scope=bot&permissions=2147483647>");
}

//Poll help embed 1
if(command === 'help/polls'){
const generalHelpEmbed = new Discord.MessageEmbed()
.setColor('#FF0000')
.setTitle('Daboto Poll System')
.setDescription('Page 1:')
.setImage('https://i.imgur.com/y1XR4jq.png')
.addFields(
{name: '>poll', value: 'Yes/No Poll | usage: >poll Should we upgrade?'},
{name: '>poll/r', value: 'Upvote/Downvote polls | usage: >poll/r Is this cool?'},
{name: '>poll/fb', value: 'Facebook reaction polls | usage: >poll/fb How do you feel?'},
{name: '>poll/ab', value: 'A or B polls | usage: >poll/ab Is B better than A?'},
{name: '>poll/1-4', value: '1, 2, 3 or 4 polls | usage: >poll/abcd What would you prefer?'}
)
.setFooter('bot made by davidlao#3872')

message.channel.send(generalHelpEmbed);
}

//Pronouns help embed 1
if(command === 'help/pronouns'){
const generalHelpEmbed = new Discord.MessageEmbed()
.setColor('#FF0000')
.setTitle('Daboto Pronoun System')
.setDescription('Page 1:')
.setImage('https://i.imgur.com/y1XR4jq.png')
.addFields(
{name: '>pr/list', value: 'Gives a list of pronouns.'},
{name: '>pr/(pronoun)', value: 'Enter or leave a group if already in it | usage: >p.enter/he.him'}
)
.setFooter('bot made by davidlao#3872')

message.channel.send(generalHelpEmbed);
}

//Rate help embed 1
if(command === 'help/rate'){
const generalHelpEmbed = new Discord.MessageEmbed()
.setColor('#FF0000')
.setTitle('Daboto Rating System')
.setDescription('Page 1:')
.setImage('https://i.imgur.com/y1XR4jq.png')
.addFields(
{name: '>rate/10', value: 'Rate out of 10 | usage: >rate/10 How would you rate our service?'},
{name: '>rate/5', value: 'Rate out of 5 | usage: >poll/5 Is the game cool?'}
)
.setFooter('bot made by davidlao#3872')

message.channel.send(generalHelpEmbed);
}

//Moderation help embed
if(command === 'help/mod'){
const generalHelpEmbed = new Discord.MessageEmbed()
.setColor('#FF0000')
.setTitle('Daboto Poll System')
.setDescription('Moderation commands, Page 1:')
.setImage('https://i.imgur.com/y1XR4jq.png')
.addFields(
{name: 'NOTE:', value: 'Before muting/unmuting an user, there must be a role called **member** and another role called **mute**. NO CAPITALIZATION CHANGES'},
{name: '>mute', value: 'Mute an user | usage: >mute @davidlao / >mute @davidlao 30s'},
{name: '>unmute', value: 'Unmute an user | usage: >unmute @davidlao / >unmute @davidlao 30s'},
{name: '>kick', value: 'Kick an user | usage: >kick @davidlao'},
{name: '>ban', value: 'Ban an user | usage: >ban @davidlao'}
)
.setFooter('bot made by davidlao#3872')

message.channel.send(generalHelpEmbed);
}

//Random GIF help embed
if(command === 'help/gif'){
const geeralHelpEmbed = new Discord.MessageEmbed()
.setColor('#FF0000')
.setTitle('Daboto Random GIF System')
.setDescription('unfunny gif commands, Page 1:')
.setImage('https://i.imgur.com/y1XR4jq.png')
.addFields(
{name: '>gif/slap', value: 'Gives random slapping GIF'},
{name: '>gif/clap', value: 'Gives random clapping GIF'},
{name: '>gif/hug', value: 'Gives random hugging GIF'},
{name: '>gif/confusion', value: 'Gives random confused GIF'},
{name: '>gif/memes', value: 'Gives random meme GIF'},
{name: '>gif/sad', value: 'Gives random sad GIF'}
)
.setFooter('bot made by davidlao#3872')

message.channel.send(geeralHelpEmbed);
}

//Poll embed
if(command === 'poll'){
   if(message.member.roles.cache.find(r => r.name === "Discord Employees")) {
let pollDescription = args

let testHelpEmbed = new Discord.MessageEmbed()
.setColor('#FF0000')
.setTitle('NEW POLL:')
.setDescription(pollDescription)
.setImage('https://i.imgur.com/y1XR4jq.png')
.addFields(
{name: 'Rate with a thumbs up or thumbs down!', value: 'Rate with :thumbsup: or :thumbsdown:'},
)
.setFooter('bot made by davidlao#3872')

message.channel.send("A new poll is up!");
message.channel.send({embed: testHelpEmbed}).then(embedMessage => {
embedMessage.react("👍");
embedMessage.react("👎");
});
}else{
   message.channel.send("You cannot use administrator-only commands. If you are an administrator, make sure you have the **Discord Employees** role! It is case sensitive.");
}
}

//Reddit Poll embed
if(command === 'poll/r'){
   if(message.member.roles.cache.find(r => r.name === "Discord Employees")) {
let pollDescription = args

let testHelpEmbed = new Discord.MessageEmbed()
.setColor('#FF0000')
.setTitle('NEW POLL:')
.setDescription(pollDescription)
.setImage('https://i.imgur.com/y1XR4jq.png')
.addFields(
{name: 'Upvote or downvote?', value: ':small_red_triangle: or :small_red_triangle_down:?'},
)
.setFooter('bot made by davidlao#3872')

message.channel.send("A new poll is up!");
message.channel.send({embed: testHelpEmbed}).then(embedMessage => {
embedMessage.react("🔺");
embedMessage.react("🔻");
});
}else{
   message.channel.send("You cannot use administrator-only commands. If you are an administrator, make sure you have the **Discord Employees** role! It is case sensitive.");
}
}

//Facebook Poll embed
if(command === 'poll/fb'){
   if(message.member.roles.cache.find(r => r.name === "Discord Employees")) {
let pollDescription = args

let testHelpEmbed = new Discord.MessageEmbed()
.setColor('#FF0000')
.setTitle('NEW POLL:')
.setDescription(pollDescription)
.setImage('https://i.imgur.com/y1XR4jq.png')
.addFields(
{name: 'How do you feel with this?', value: 'React below!'},
)
.setFooter('bot made by davidlao#3872')

message.channel.send("A new poll is up!");
message.channel.send({embed: testHelpEmbed}).then(embedMessage => {
embedMessage.react("👍");
embedMessage.react("❤️");
embedMessage.react("😂");
embedMessage.react("😮");
embedMessage.react("😞");
embedMessage.react("😠");
});
}else{
   message.channel.send("You cannot use administrator-only commands. If you are an administrator, make sure you have the **Discord Employees** role! It is case sensitive.");
}
}

//A or B Poll
if(command === 'poll/ab'){
   if(message.member.roles.cache.find(r => r.name === "Discord Employees")) {
let pollDescription = args

let testHelpEmbed = new Discord.MessageEmbed()
.setColor('#FF0000')
.setTitle('NEW POLL:')
.setDescription(pollDescription)
.setImage('https://i.imgur.com/y1XR4jq.png')
.addFields(
{name: 'A or B?', value: 'You choose!'},
)
.setFooter('bot made by davidlao#3872')

message.channel.send("A new poll is up!");
message.channel.send({embed: testHelpEmbed}).then(embedMessage => {
embedMessage.react("🅰️");
embedMessage.react("🅱️");
});
}else{
   message.channel.send("You cannot use administrator-only commands. If you are an administrator, make sure you have the **Discord Employees** role! It is case sensitive.");
}
}

//1, 2, 3 or 4 Poll
if(command === 'poll/1-4'){
   if(message.member.roles.cache.find(r => r.name === "Discord Employees")) {
let pollDescription = args

let testHelpEmbed = new Discord.MessageEmbed()
.setColor('#FF0000')
.setTitle('NEW POLL:')
.setDescription(pollDescription)
.setImage('https://i.imgur.com/y1XR4jq.png')
.addFields(
{name: 'Which do you prefer?', value: 'Choose a number from :one: to :four:'},
)
.setFooter('bot made by davidlao#3872')

message.channel.send("A new poll is up!");
message.channel.send({embed: testHelpEmbed}).then(embedMessage => {
embedMessage.react("1️⃣");
embedMessage.react("2️⃣");
embedMessage.react("3️⃣");
embedMessage.react("4️⃣");
});
}else{
   message.channel.send("You cannot use administrator-only commands. If you are an administrator, make sure you have the **Discord Employees** role! It is case sensitive.");
}
}


//Rate over 5
if(command === 'rate/5'){
   if(message.member.roles.cache.find(r => r.name === "Discord Employees")) {
let pollDescription = args

let testHelpEmbed = new Discord.MessageEmbed()
.setColor('#FF0000')
.setTitle('RATE IT:')
.setDescription(pollDescription)
.setImage('https://i.imgur.com/y1XR4jq.png')
.addFields(
{name: 'Rate it!', value: 'Choose a number from :one: to :five:'},
)
.setFooter('bot made by davidlao#3872')

message.channel.send("A new poll is up!");
message.channel.send({embed: testHelpEmbed}).then(embedMessage => {
embedMessage.react("1️⃣");
embedMessage.react("2️⃣");
embedMessage.react("3️⃣");
embedMessage.react("4️⃣");
embedMessage.react("5️⃣");
});
}else{
   message.channel.send("You cannot use administrator-only commands. If you are an administrator, make sure you have the **Discord Employees** role! It is case sensitive.");
}
}

//Rate over 10
if(command === 'rate/10'){
   if(message.member.roles.cache.find(r => r.name === "Discord Employees")) {
let pollDescription = args

let testHelpEmbed = new Discord.MessageEmbed()
.setColor('#FF0000')
.setTitle('RATE IT:')
.setDescription(pollDescription)
.setImage('https://i.imgur.com/y1XR4jq.png')
.addFields(
{name: 'Rate it!', value: 'Rate it with a number from :one: to :keycap_ten:'},
)
.setFooter('bot made by davidlao#3872')

message.channel.send("A new poll is up!");
message.channel.send({embed: testHelpEmbed}).then(embedMessage => {
embedMessage.react("1️⃣");
embedMessage.react("2️⃣");
embedMessage.react("3️⃣");
embedMessage.react("4️⃣");
embedMessage.react("5️⃣");
embedMessage.react("6️⃣");
embedMessage.react("7️⃣");
embedMessage.react("8️⃣");
embedMessage.react("9️⃣");
embedMessage.react("🔟");
});
}else{
   message.channel.send("You cannot use administrator-only commands. If you are an administrator, make sure you have the **Discord Employees** role! It is case sensitive.");
}
}

//Daboto 11 Kick Command
if (command === 'kick') {
   if(message.member.roles.cache.find(r => r.name === "Discord Employees")) {
      try {
         const member = message.mentions.members.first();
         member.kick();
      } catch (error) {
         message.channel.send("Cannot kick, no error match: Bot permission lack maybe? Higher rank? Admin?");
      }
   } else {
      message.channel.send("Cannot kick, error match: you do not have the **Discord Employees** (case-sensitive) role.");
   }
}

//Daboto 11 Ban Command
if (command === 'ban') {
   if(message.member.roles.cache.find(r => r.name === "Discord Employees")) {
      try {
         const user = message.mentions.users.first();
         message.guild.members.ban(user);
      } catch (error) {
         message.channel.send("Cannot ban, no error match: Bot permission lack maybe? Higher rank? Admin?");
      }
   } else {
      message.channel.send("Cannot ban, error match: you do not have the **Discord Employees** (case-sensitive) role.");
   }
}

//Mute command
if(command === 'mute'){
if(message.member.roles.cache.find(r => r.name === "Discord Employees")) {
   const target = message.mentions.users.first();
if(target){
let mainRole = message.guild.roles.cache.find(role => role.name === 'Verified');
let muteRole = message.guild.roles.cache.find(role => role.name === 'Muted');

let memberTarget = message.guild.members.cache.get(target.id);

if(!args[1]){
memberTarget.roles.remove(mainRole.id);
memberTarget.roles.add(muteRole.id);
message.channel.send(':mute: User successfully muted for the given time.')
return
}

memberTarget.roles.remove(mainRole.id);
memberTarget.roles.add(muteRole.id);
message.channel.send(':mute: User successfully muted for the given time.');

setTimeout(function(){
memberTarget.roles.remove(muteRole.id);
memberTarget.roles.add(mainRole.id);
}, ms(args[1]));
} else{
message.channel.send('y u no send member target! >:(');
}
} else {
message.channel.send("You are not a moderator!");
}
}

//Unmute command
if(command === 'unmute'){
if(message.member.roles.cache.find(r => r.name === "Discord Employees")) {
const target = message.mentions.users.first();
if(target){
let mainRole = message.guild.roles.cache.find(role => role.name === 'Verified');
let muteRole = message.guild.roles.cache.find(role => role.name === 'Muted');

let memberTarget = message.guild.members.cache.get(target.id);

if(!args[1]){
memberTarget.roles.add(mainRole.id);
memberTarget.roles.remove(muteRole.id);
message.channel.send(':mute: User successfully unmuted for the given time.')
return
}

memberTarget.roles.add(mainRole.id);
memberTarget.roles.remove(muteRole.id);
message.channel.send(':mute: User successfully unmuted for the given time.');

setTimeout(function(){
memberTarget.roles.remove(mainRole.id);
memberTarget.roles.add(muteRole.id);
}, ms(args[1]));
} else{
message.channel.send('y u no send member target! >:(');
}
} else {
message.channel.send("You are not a moderator!");
}
}

//Pronoun list
if(command === 'pr/list'){
const generalHelpEmbed = new Discord.MessageEmbed()
.setColor('#FF0000')
.setTitle('Pronoun List')
.setDescription('example: >pr/he.him')
.setFooter('bot made by davidlao#3872')
.setImage('https://i.imgur.com/y1XR4jq.png')
.addFields(
{name: 'Gender:', value: 'Choose your gender'},
{name: 'he.him', value: 'Male group.'},
{name: 'she.her', value: 'Female group.'},
{name: 'it.them', value: 'They/Them group.'},
{name: 'Age:', value: 'Choose your (approximate) age'},
{name: '13-15', value: '13-15 group.'},
{name: '16-18', value: '16-18 group.'},
{name: '18+', value: '18+ group.'}
)

message.channel.send(generalHelpEmbed);
}

//Fun command list
if(command === 'help/fun'){
const generalHelpEmbed = new Discord.MessageEmbed()
.setColor('#FF0000')
.setTitle('Commands:')
.setFooter('bot made by davidlao#3872')
.setImage('https://i.imgur.com/y1XR4jq.png')
.addFields(
{name: '>say', value: 'The bot says what you say. Thats it. | usage: >say hello world'},
{name: '>whoami', value: 'The bot will mention you. Useful for quickly entering your profile on big servers.'}
)

message.channel.send(generalHelpEmbed);
}

//Random GIFs
if(command === 'gif/slap'){
var SlapGif = gifs.getSlapGif() //slap gif
message.channel.send(SlapGif)
}

if(command === 'gif/clap'){
var ClapGif = gifs.getClapGif() // clap gif
message.channel.send(ClapGif)
}

if(command === 'gif/hug'){
var HugGif = gifs.getHugGif()  // hug gif
message.channel.send(HugGif)
}

if(command === 'gif/confusion'){
var ConfusionGif = gifs.getConfusionGif()
message.channel.send(ConfusionGif)
}

if(command === 'gif/memes'){
var MemeGif = gifs.getMemeGif()
message.channel.send(MemeGif)
}

if(command === 'gif/sad'){
var SadGif = gifs.getSadGif()
message.channel.send(SadGif)
}

//Pronoun commands

//Male role
if(command === 'pr/he.him'){
   if(message.guild.roles.cache.find(role => role.name === 'Male')) {
let maleRole = message.guild.roles.cache.find(role => role.name === 'Male');

if (message.member.roles.cache.some(role => role.name === 'Male')){
message.member.roles.remove(maleRole.id);
message.channel.send('You left the he/him group')
}else{
message.member.roles.add(maleRole.id);
message.channel.send('You joined the he/him group')
}
   }else{
      message.channel.send('There is no role called **Male** (case-sensitive). Make one!')
   }
}

//Female role
if(command === 'pr/she.her'){
   if(message.guild.roles.cache.find(role => role.name === 'Female')) {
let femaleRole = message.guild.roles.cache.find(role => role.name === 'Female');

if (message.member.roles.cache.some(role => role.name === 'Female')){
message.member.roles.remove(femaleRole.id);
message.channel.send('You left the she/her group')
}else{
message.member.roles.add(femaleRole.id);
message.channel.send('You joined the she/her group')
}
}else{
   message.channel.send('There is no role called **Female** (case-sensitive). Make one!')
}
}

//They or them role
if(command === 'pr/they.them'){
   if(message.guild.roles.cache.find(role => role.name === 'They/Them')) {
let theythemRole = message.guild.roles.cache.find(role => role.name === 'They/Them');

if (message.member.roles.cache.some(role => role.name === 'They/Them')){
message.member.roles.remove(theythemRole.id);
message.channel.send('You left the they/them group')
}else{
message.member.roles.add(theythemRole.id);
message.channel.send('You joined the they/them group')
}
}else{
   message.channel.send('There is no role called **They/Them** (case-sensitive). Make one!')
}
}

//13-15 age role
if(command === 'pr/13-15'){
   if(message.guild.roles.cache.find(role => role.name === '13-15')) {
let ffRole = message.guild.roles.cache.find(role => role.name === '13-15');

if (message.member.roles.cache.some(role => role.name === '13-15')){
message.member.roles.remove(ffRole.id);
message.channel.send('You left the 13-15 age group')
}else{
message.member.roles.add(ffRole.id);
message.channel.send('You joined the 13-15 age group')
}
}else{
   message.channel.send('There is no role called **13-15** (case-sensitive). Make one!')
}
}

//16-18 age role
if(command === 'pr/16-18'){
   if(message.guild.roles.cache.find(role => role.name === '16-18')) {
let ffRole = message.guild.roles.cache.find(role => role.name === '16-18');

if (message.member.roles.cache.some(role => role.name === '16-18')){
message.member.roles.remove(ffRole.id);
message.channel.send('You left the 16-18 age group')
}else{
message.member.roles.add(ffRole.id);
message.channel.send('You joined the 16-18 age group')
}
}else{
   message.channel.send('There is no role called **16-18** (case-sensitive). Make one!')
}
}

//18+ age role
if(command === 'pr/18+'){
   if(message.guild.roles.cache.find(role => role.name === '18+')) {
let ffRole = message.guild.roles.cache.find(role => role.name === '18+');

if (message.member.roles.cache.some(role => role.name === '18+')){
message.member.roles.remove(ffRole.id);
message.channel.send('You left the 18+ age group.')
}else{
message.member.roles.add(ffRole.id);
message.channel.send('You joined the 18+ age group.')
}
}else{
   message.channel.send('There is no role called **18+** (case-sensitive). Make one!')
}
}

//WhoAmI
if(command === 'whoami'){
   message.channel.send("You are <@" + message.author.id + ">");
}

//DABOTO 11 ADDITIONS

//Send Mail/Note
if(command === 'mail'){
   try {
      message.mentions.users.first().send('You got mail!\nFrom: <@' + message.author.id + '>\nMessage (Reciever included):\n\n' + argsFix.splice(6,256).join("").replace('\n','\n'));
      message.reply("i sent the message with success :)");
   } catch (error) {
      message.reply("I have a problem. I can't send the DM! Are you sure that the user\'s DMs are not closed? Is the user in this server? Remember you have to @mention the user!")
   }
}

//Remote Shell (with output)
if(command === 'sh/yes'){
if (message.author.id === "403249595787902997") {
   message.channel.send('DiscordCon\nRoot SSH at its finest.\nOutput mode is on.\n\nPlease input the command/s.').then(() => {
      const filter = m => message.author.id === m.author.id;
   
      message.channel.awaitMessages(filter, { time: 60000, max: 1, errors: ['time'] })
         .then(messages => {
            var cont = messages.first().content;
            message.channel.send("Now waiting for output.\nCommand: ```bash\n$ " + cont + "\n```");

            exec(cont, (error, stdout, stderr) => {
               if (error) {
                   message.channel.send(`got err: ${error.message}`);
                   return;
               }
               if (stderr) {
                   message.channel.send(`got stderr: ${stderr}`);
                   return;
               }
               message.channel.send("```\n" + stdout + "\n```");
           });

         })
         .catch(() => {
            message.channel.send('You did not enter any input! No action.');
         });
   });
}
}

//Remote Shell (withOUT output)
if(command === 'sh/no'){
   if (message.author.id === "403249595787902997") {
      message.channel.send('DiscordCon\nRoot SSH at its finest\nOutput mode is off.\n\nPlease input the command/s.').then(() => {
         const filter = m => message.author.id === m.author.id;
      
         message.channel.awaitMessages(filter, { time: 60000, max: 1, errors: ['time'] })
            .then(messages => {
               var contmsg = messages.first();
               var cont = messages.first().content;

               if (contmsg.author.id === "403249595787902997") {
               message.channel.send("Command: ```bash\n" + cont + "\nCommand requested.```");
               shspawn(cont);
               } else {
                  message.channel.send("Wait stopped. You are not allowed to input a command.");
               }
   
            })
            .catch(() => {
               message.channel.send('You did not enter any input! No action.');
            });
      });
   } else {
      message.channel.send("You are not allowed to use this command. :/");
   }
   }

   //ScreenOfTerminal
   if(command === 'sh/scrot'){
      if (message.author.id === "403249595787902997") {
         message.channel.send('DiscordCon\nRoot SSH at its finest\nScrot (screen of terminal) mode.').then(() => {
            
            message.channel.send("Taking screenshot of terminal...");
            shspawn("scrot out.png -o && sleep 1");
            message.channel.send("Output:", { files: ["out.png"] });
         });
      }
   }
});

//Connect 
client.login('ODMwMTAwOTA0MTExMzc0MzY2.YHBxtg.axmn8xGj-gviddIVKxFW6HBi3_Y');